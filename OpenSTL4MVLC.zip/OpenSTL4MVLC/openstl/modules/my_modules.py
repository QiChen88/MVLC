import math
import torch
import torch.nn as nn

from timm.models.layers import DropPath, trunc_normal_
from timm.models.convnext import ConvNeXtBlock
from timm.models.mlp_mixer import MixerBlock
from timm.models.swin_transformer import SwinTransformerBlock, window_partition, window_reverse
from timm.models.vision_transformer import Block as ViTBlock

from .layers import (HorBlock, ChannelAggregationFFN, MultiOrderGatedAggregation,
                     PoolFormerBlock, CBlock, SABlock, MixMlp, VANBlock)

from torch.nn import functional as F
from functools import partial
from einops.layers.torch import Rearrange, Reduce

class BasicConv2d(nn.Module):

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size=3,
                 stride=1,
                 padding=0,
                 dilation=1,
                 upsampling=False,
                 act_norm=False,
                 act_inplace=True):
        super(BasicConv2d, self).__init__()
        self.act_norm = act_norm
        if upsampling is True:
            self.conv = nn.Sequential(*[
                nn.Conv2d(in_channels, out_channels*4, kernel_size=kernel_size,
                          stride=1, padding=padding, dilation=dilation),
                nn.PixelShuffle(2)
            ])
        else:
            self.conv = nn.Conv2d(
                in_channels, out_channels, kernel_size=kernel_size,
                stride=stride, padding=padding, dilation=dilation)

        self.norm = nn.GroupNorm(2, out_channels)
        self.act = nn.SiLU(inplace=act_inplace)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d)):
            trunc_normal_(m.weight, std=.02)
            nn.init.constant_(m.bias, 0)

    def forward(self, x):
        y = self.conv(x)
        if self.act_norm:
            y = self.act(self.norm(y))
        return y


class ConvSC(nn.Module):

    def __init__(self,
                 C_in,
                 C_out,
                 kernel_size=3,
                 downsampling=False,
                 upsampling=False,
                 act_norm=True,
                 act_inplace=True):
        super(ConvSC, self).__init__()

        stride = 2 if downsampling is True else 1
        padding = (kernel_size - stride + 1) // 2

        self.conv = BasicConv2d(C_in, C_out, kernel_size=kernel_size, stride=stride,
                                upsampling=upsampling, padding=padding,
                                act_norm=act_norm, act_inplace=act_inplace)

    def forward(self, x):
        y = self.conv(x)
        return y


class GroupConv2d(nn.Module):

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size=3,
                 stride=1,
                 padding=0,
                 groups=1,
                 act_norm=False,
                 act_inplace=True):
        super(GroupConv2d, self).__init__()
        self.act_norm=act_norm
        if in_channels % groups != 0:
            groups=1
        self.conv = nn.Conv2d(
            in_channels, out_channels, kernel_size=kernel_size,
            stride=stride, padding=padding, groups=groups)
        self.norm = nn.GroupNorm(groups,out_channels)
        self.activate = nn.LeakyReLU(0.2, inplace=act_inplace)

    def forward(self, x):
        y = self.conv(x)
        if self.act_norm:
            y = self.activate(self.norm(y))
        return y

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6

class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)

class CoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()
        
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        

    def forward(self, x):
        identity = x                        # identity [16 512 16 16]
        n,c,h,w = x.size()
        x_h = self.pool_h(x)               # x_h [16 512 16 1]
        x_w = self.pool_w(x).permute(0, 1, 3, 2)    # x_w [16 512 16 1]
        y = torch.cat([x_h, x_w], dim=2)           # y [16 512 32 1]
        y = self.conv1(y)                         # y [16 16 32 1]
        y = self.bn1(y)                           # y [16 16 32 1]
        y = self.act(y)                           # y [16 16 32 1]
        x_h, x_w = torch.split(y, [h, w], dim=2)  # x_h [16 16 16 1]  x_w [16 16 16 1]
        x_w = x_w.permute(0, 1, 3, 2)             # x_w [16 16 1 16]
        a_h = self.conv_h(x_h).sigmoid()          # a_h [16 512 16 1]
        a_w = self.conv_w(x_w).sigmoid()          # a_w [16 512 1 16]
        out = identity * a_w * a_h                # 16 512 16 16

        return out
    


# class gInception_ST(nn.Module):
#     """A IncepU block for SimVP"""

#     def __init__(self, C_in, C_hid, C_out, incep_ker = [3,5,7,11], groups = 8):        
#         super(gInception_ST, self).__init__()
#         self.conv1 = nn.Conv2d(C_in, C_hid, kernel_size=1, stride=1, padding=0)

#         layers = []
#         for ker in incep_ker:
#             layers.append(GroupConv2d(
#                 C_hid, C_out, kernel_size=ker, stride=1,
#                 padding=ker//2, groups=groups, act_norm=True))
#         self.layers = nn.Sequential(*layers)

#     def forward(self, x):
#         x = self.conv1(x)
#         y = 0
#         for layer in self.layers:
#             y += layer(x)
#         return y


class AttentionModule(nn.Module):
    """Large Kernel Attention for SimVP"""

    def __init__(self, dim, kernel_size, dilation=3):
        super().__init__()
        d_k = 2 * dilation - 1
        d_p = (d_k - 1) // 2
        dd_k = kernel_size // dilation + ((kernel_size // dilation) % 2 - 1)
        dd_p = (dilation * (dd_k - 1) // 2)

        self.conv0 = nn.Conv2d(dim, dim, d_k, padding=d_p, groups=dim)
        self.conv_spatial = nn.Conv2d(
            dim, dim, dd_k, stride=1, padding=dd_p, groups=dim, dilation=dilation)
        self.conv1 = nn.Conv2d(dim, 2*dim, 1)

    def forward(self, x):
        u = x.clone()
        attn = self.conv0(x)           # depth-wise conv
        attn = self.conv_spatial(attn) # depth-wise dilation convolution
        
        f_g = self.conv1(attn)
        split_dim = f_g.shape[1] // 2
        f_x, g_x = torch.split(f_g, split_dim, dim=1)
        return torch.sigmoid(g_x) * f_x


class SpatialAttention(nn.Module):
    """A Spatial Attention block for SimVP"""

    def __init__(self, d_model, kernel_size=21, attn_shortcut=True):
        super().__init__()

        self.proj_1 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv
        self.activation = nn.GELU()                          # GELU
        self.spatial_gating_unit = AttentionModule(d_model, kernel_size)
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv
        self.attn_shortcut = attn_shortcut

    def forward(self, x):
        if self.attn_shortcut:
            shortcut = x.clone()
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.spatial_gating_unit(x)
        x = self.proj_2(x)
        if self.attn_shortcut:
            x = x + shortcut
        return x


class GASubBlock(nn.Module):
    """A GABlock (gSTA) for SimVP"""

    def __init__(self, dim, kernel_size=21, mlp_ratio=4.,
                 drop=0., drop_path=0.1, init_value=1e-2, act_layer=nn.GELU):
        super().__init__()
        self.norm1 = nn.BatchNorm2d(dim)
        self.attn = SpatialAttention(dim, kernel_size)
        # self.attn = TemporalAttention(dim, kernel_size)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.dim = dim
        self.norm2 = nn.BatchNorm2d(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = MixMlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        self.coordAttn = CoordAtt(inp=dim, oup=dim, reduction=32)

        self.layer_scale_1 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)
        self.mlpratio = mlp_ratio
        self.kernelsize = kernel_size

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'layer_scale_1', 'layer_scale_2'}

    def forward(self, x):
        x = x + self.coordAttn(x)
        x = x + self.drop_path(
            self.layer_scale_1.unsqueeze(-1).unsqueeze(-1) * self.attn(self.norm1(x)))
        x = x + self.drop_path(
            self.layer_scale_2.unsqueeze(-1).unsqueeze(-1) * self.mlp(self.norm2(x)))
    
        return x


class TemporalAttention(nn.Module):
    """A Temporal Attention block for Temporal Attention Unit"""

    def __init__(self, d_model, kernel_size=21, attn_shortcut=True):
        super().__init__()

        self.proj_1 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv
        self.activation = nn.GELU()                          # GELU
        self.spatial_gating_unit = TemporalAttentionModule(d_model, kernel_size)
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv
        self.attn_shortcut = attn_shortcut

    def forward(self, x):
        if self.attn_shortcut:
            shortcut = x.clone()
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.spatial_gating_unit(x)
        x = self.proj_2(x)
        if self.attn_shortcut:
            x = x + shortcut
        return x

# class AttnGate(nn.Module):
#     def __init__(self, dim, kernel_size, dilation=3):
#         super().__init__()
#         d_k = 2 * dilation - 1
#         d_p = (d_k - 1) // 2
#         dd_k = kernel_size // dilation + ((kernel_size // dilation) % 2 - 1)
#         dd_p = (dilation * (dd_k - 1) // 2)

#         self.conv0 = nn.Conv2d(dim, dim, d_k, padding=d_p, groups=dim)
#         self.conv_spatial = nn.Conv2d(
#             dim, dim, dd_k, stride=1, padding=dd_p, groups=dim, dilation=dilation)
#         self.conv1 = nn.Conv2d(dim, dim, 1)

#     def forward(self, x):
#         out = self.conv0(x)
#         out = self.conv_spatial(x)
#         out = self.conv1(x)

#         return out

class TemporalAttentionModule(nn.Module):
    """Large Kernel Attention for SimVP"""

    def __init__(self, dim, kernel_size, dilation=3, reduction=16):
        super().__init__()

        self.sa = ST_rfb(channels=dim)

    def forward(self, x):
        u = x.clone()
        sa = self.sa(x)

        return  u * sa


# # ST-RFB 
# class ST_SubBlock(GASubBlock):
#      def __init__(self, dim, kernel_size=21, mlp_ratio=4.,
#                  drop=0., drop_path=0.1, init_value=1e-2, act_layer=nn.GELU):
#         super().__init__(dim=dim, kernel_size=kernel_size, mlp_ratio=mlp_ratio,
#                  drop=drop, drop_path=drop_path, init_value=init_value, act_layer=act_layer)
        
#         self.attn = TemporalAttention(dim, kernel_size)
#         # self.attn = ST_rfb(channels=dim)

    

# ST-RFB 
class ST_SubBlock(GASubBlock):
     def __init__(self, dim, kernel_size=21, mlp_ratio=4.,
                 drop=0., drop_path=0.1, init_value=1e-2, act_layer=nn.GELU):
        super().__init__(dim=dim, kernel_size=kernel_size, mlp_ratio=mlp_ratio,
                 drop=drop, drop_path=drop_path, init_value=init_value, act_layer=act_layer)
        
        self.attn = TemporalAttention(dim, kernel_size)
        # self.attn = ST_rfb(channels=dim)

 


# '''https://github.com/hfarhaditolie/DICAM/blob/main/UIEB/Config/models.py''' 
# class Flatten(nn.Module):
#     def forward(self, inp):
#         return inp.view(inp.size(0), -1)
# class CAM(nn.Module):
#     def __init__(self,in_channels,reduction_ratio):
#         super(CAM, self).__init__()
#         self.module = nn.Sequential(
#             # nn.AdaptiveAvgPool2d((1,1)),
#             # Flatten(),
#             nn.Linear(in_channels, in_channels // reduction_ratio),
#             nn.Softsign(),
#             # nn.ReLU(inplace=True),
#             nn.Linear(in_channels // reduction_ratio, in_channels ),
#             nn.Softsign()
#             # nn.Sigmoid()
#             )
#     def forward(self,input):
#         # return self.module(input)
#         return input* self.module(input).unsqueeze(2).unsqueeze(3).expand_as(input)
    
# '''https://github.com/yusunnny/CST-former/blob/main/architecture/CST_details/layers.py'''
# class SE_MSCAM(nn.Module):
#     def __init__(self, channel, reduction=16):
#         super(SE_MSCAM, self).__init__()
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.se1 = nn.Sequential(
#             nn.Conv2d(channel, channel // reduction, kernel_size=1),
#             nn.ReLU(inplace=True),
#             nn.Conv2d(channel // reduction, channel, kernel_size=1),
#             nn.BatchNorm2d(channel)
#         )
#         self.se2 = nn.Sequential(
#             nn.Conv2d(channel, channel // reduction, kernel_size=1),
#             # nn.Conv2d(channel, channel, kernel_size=3, dilation=2, padding=2),
#             nn.ReLU(inplace=True),
#             nn.Conv2d(channel // reduction, channel, kernel_size=1),
#             # nn.Conv2d(channel, channel, kernel_size=3, dilation=2, padding=2),
#             nn.BatchNorm2d(channel)
#         )
#         self.activation = nn.Sigmoid()

#     def forward(self, x):
#         b, c, _, _ = x.size()
#         y1 = self.avg_pool(x).view(b, c, 1, 1)
#         y1 = self.se1(y1).view(b, c, 1, 1)

#         y2 = self.se2(x)

#         y = y1.expand_as(y2) + y2
#         y = self.activation(y)
#         return x * y
    

# class CALayer(nn.Module):
#     def __init__(self, channel, reduction=16):
#         super(CALayer, self).__init__()
#         # global average pooling: feature --> point
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         # feature channel downscale and upscale --> channel weight
#         self.conv_du = nn.Sequential(
#             nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
#             nn.ReLU(inplace=True),
#             nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
#             nn.Sigmoid()
#         )

#     def forward(self, x):
#         y = self.avg_pool(x)
#         y = self.conv_du(y)
#         return y

# class eca_layer(nn.Module):
#     """Constructs a ECA module.

#     Args:
#         channel: Number of channels of the input feature map
#         k_size: Adaptive selection of kernel size
#     """
#     def __init__(self, channel, k_size=3, reduction=4):
#         super(eca_layer, self).__init__()
#         # self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         # self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
#         # self.sigmoid = nn.Sigmoid()

#         self.reduction = reduction
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.fc = nn.Sequential(
#             nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False),
#             # nn.ReLU(True),
#             nn.Sigmoid(),
#             nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False),
#             nn.Sigmoid(),
#         )

#     def forward(self, x):
#         # feature descriptor on the global spatial information
#         y = self.avg_pool(x)
#         # print(y.shape)
        
#         # print(y.shape)
#         # Two different branches of ECA module
#         # y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)

#         y = self.fc(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)


#         # Multi-scale information fusion
#         # y = self.sigmoid(y)
#         # print(y.shape)

#         return y

#         # return x * y.expand_as(x)


# class h_sigmoid(nn.Module):
#     def __init__(self, inplace=True):
#         super(h_sigmoid, self).__init__()
#         self.relu = nn.ReLU6(inplace=inplace)

#     def forward(self, x):
#         return self.relu(x + 3) / 6




class TemporalLayer(nn.Module):
    def __init__(self, channel, ratio=4):
        super(TemporalLayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Sequential(
            nn.Linear(channel, channel // ratio),    # channel
            nn.ReLU(inplace=True),
            nn.Linear(channel // ratio, channel),

            nn.Sigmoid()
        )
        self.fc2 = nn.Sequential(nn.Conv2d(channel, channel, kernel_size=1, bias=False),
                                    nn.BatchNorm2d(channel),
          
                                  nn.PReLU(channel))

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc1(y).view(b, c, 1, 1)
        out = x * y
        out = self.fc2(out)
        return out


class newBasicConv(nn.Module):

    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=True, bias=False):
        super(newBasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,
                              dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.PReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x


    

class ST_rfb(nn.Module):
    def __init__(self, channels=512):
        super(ST_rfb, self).__init__()
        # self.global_se = SELayer(channels)
        # self.reduce = nn.Sequential(nn.Conv2d(channels, channels, kernel_size=1, bias=False),
        #                             nn.BatchNorm2d(channels),
        #   
        #                           nn.PReLU(channels))
        # self.temporal = TemporalLayer(channels, ratio=4)
        self.br0 = nn.Sequential(
            newBasicConv(channels, channels, kernel_size=1, bias=False,
                      bn=True, relu=True),
            newBasicConv(channels, channels, kernel_size=3, dilation=1, padding=1, groups=channels, bias=False,
                      relu=False),
        )
        self.br1 = nn.Sequential(
            newBasicConv(channels, channels, kernel_size=1, dilation=1, bias=False, bn=True, relu=True),
            newBasicConv(channels, channels, kernel_size=3, dilation=1, padding=1, groups=channels, bias=False,
                      bn=True, relu=False),
            

            newBasicConv(channels, channels, kernel_size=3, dilation=3, padding=3, groups=channels, bias=False,
                      relu=False),
        )
        self.br2 = nn.Sequential(
            newBasicConv(channels, channels, kernel_size=1, dilation=1, bias=False, bn=True, relu=True),
            newBasicConv(channels, channels, kernel_size=5, dilation=1, padding=2, groups=channels, bias=False,
                      bn=True, relu=False),
            

            newBasicConv(channels, channels, kernel_size=3, dilation=5, padding=5, groups=channels, bias=False,
                      relu=False),   
        )
        self.br3 = nn.Sequential(
            newBasicConv(channels, channels, kernel_size=1, dilation=1, bias=False, bn=True, relu=True),
            newBasicConv(channels, channels, kernel_size=7, dilation=1, padding=3, groups=channels, bias=False,
                      bn=True, relu=False),
            

            newBasicConv(channels, channels, kernel_size=3, dilation=7, padding=7, groups=channels, bias=False,
                      relu=False),
        )
        self.sa_fusion = newBasicConv(channels * 4 + channels, channels, kernel_size=1, bias=False, bn=True,
                                      relu=True)
        
    def forward(self, x):
        # t_attn = self.temporal(x)
        x0 = self.br0(x)                       
        x1 = self.br1(x)                       
        x2 = self.br2(x)  
        x3 = self.br3(x)                       
        out = self.sa_fusion(torch.cat([x, x0, x1, x2,x3], dim=1))
        
        return out

    # def forward(self, x):
    #     t_attn = self.temporal(x)
    #     x0 = self.br0(x)                       
    #     x1 = self.br1(t_attn)                       
    #     x2 = self.br2(t_attn)  
    #     x3 = self.br3(t_attn)                       
    #     out = self.sa_fusion(torch.cat([x, x0, x1, x2,x3], dim=1))
    #     return out
     