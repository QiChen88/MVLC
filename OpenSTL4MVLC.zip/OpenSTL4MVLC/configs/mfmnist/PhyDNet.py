method = 'PhyDNet'
# model
patch_size = 4
# training
lr = 5e-4
batch_size = 16
sched = 'onecycle'