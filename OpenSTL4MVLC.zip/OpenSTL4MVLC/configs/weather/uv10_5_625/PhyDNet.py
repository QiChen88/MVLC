method = 'PhyDNet'
# model
patch_size = 2
# training
lr = 1e-3
batch_size = 16
sched = 'cosine'
warmup_epoch = 0