import torch
from torch import nn
import torch.nn.functional as F
from openstl.modules import (ConvSC,  GASubBlock, ST_SubBlock,)
import math
from timm.models.layers import DropPath

import copy
import sys

class myModel(nn.Module):

    def __init__(self, in_shape, hid_S=16, hid_T=256, N_S=4, N_T=4, model_type='gSTA',
                 mlp_ratio=8., drop=0.0, drop_path=0.0, spatio_kernel_enc=3,
                 spatio_kernel_dec=3, act_inplace=True, **kwargs):
        super(myModel, self).__init__()
        T, C, H, W = in_shape  # T is pre_seq_length
        H, W = int(H / 2**(N_S/2)), int(W / 2**(N_S/2))  # downsample 1 / 2**(N_S/2)
        act_inplace = False
        self.enc = Encoder(C, hid_S, N_S, spatio_kernel_enc, act_inplace=act_inplace)
        self.dec = Decoder(hid_S, C, N_S, spatio_kernel_dec, act_inplace=act_inplace)
        self.hid = MidMetaNet(T, hid_S, hid_T, N_T,input_resolution=(H, W), model_type=model_type,mlp_ratio=mlp_ratio, drop=drop, drop_path=drop_path)
       

    def forward(self, x_raw, **kwargs):
        B, T, C, H, W = x_raw.shape
        x = x_raw.view(B*T, C, H, W)

        embed, skip = self.enc(x)
        _, C_, H_, W_ = embed.shape

        z = embed.view(B, T, C_, H_, W_)
    
        hid = self.hid(z)
        hid = hid.reshape(B*T, C_, H_, W_)

        Y = self.dec(hid, skip)
        Y = Y.reshape(B, T, C, H, W)
        return Y


def sampling_generator(N, reverse=False):
    samplings = [False, True] * (N // 2)
    if reverse: return list(reversed(samplings[:N]))
    else: return samplings[:N]


class Encoder(nn.Module):
    """3D Encoder from SimVP"""

    def __init__(self, C_in, C_hid, N_S, spatio_kernel, act_inplace=True):
        samplings = sampling_generator(N_S)
        super(Encoder, self).__init__()
        self.enc = nn.Sequential(
              ConvSC(C_in, C_hid, spatio_kernel, downsampling=samplings[0],
                     act_inplace=act_inplace),
            *[ConvSC(C_hid, C_hid, spatio_kernel, downsampling=s,
                     act_inplace=act_inplace) for s in samplings[1:]]
        )

    def forward(self, x):  # B*4, 3, 128, 128
        enc1 = self.enc[0](x)
        latent = enc1
        for i in range(1, len(self.enc)):
            latent = self.enc[i](latent)
        return latent, enc1


class Decoder(nn.Module):
    """3D Decoder from SimVP"""

    def __init__(self, C_hid, C_out, N_S, spatio_kernel, act_inplace=True):
        samplings = sampling_generator(N_S, reverse=True)
        super(Decoder, self).__init__()
        self.dec = nn.Sequential(
            *[ConvSC(C_hid, C_hid, spatio_kernel, upsampling=s,
                     act_inplace=act_inplace) for s in samplings[:-1]],
              ConvSC(C_hid, C_hid, spatio_kernel, upsampling=samplings[-1],
                     act_inplace=act_inplace)
        )
        self.readout = nn.Conv2d(C_hid, C_out, 1)

    def forward(self, hid, enc1=None):
        for i in range(0, len(self.dec)-1):
            hid = self.dec[i](hid)
        Y = self.dec[-1](hid + enc1)
        Y = self.readout(Y)
        return Y

class MidMetaNet(nn.Module):

    def __init__(self,T, hid_S, channel_hid, N2,
                 input_resolution=None, model_type=None,
                 mlp_ratio=4., drop=0.0, drop_path=0.1, init_value=1e-2, act_layer=nn.GELU):
        super(MidMetaNet, self).__init__()
        assert N2 >= 2 and mlp_ratio > 1
        self.N2 = N2
        dpr = [  # stochastic depth decay rule
            x.item() for x in torch.linspace(1e-2, drop_path, self.N2)]
        

        enc_layers = []

        for i in range(0, N2):
            enc_layers.append(EncoderLayer(T, d_model=hid_S))

        self.enc = nn.Sequential(*enc_layers)    

    def forward(self, x):
        B, T, C, H, W = x.shape
        for i in range(self.N2):
            x = self.enc[i](x)     # [16, 10, 128, 16, 16]   
        return x


class EncoderLayer(nn.Module):
    def __init__(self, T, d_model,  mlp_ratio=4., drop=0.0, drop_path=0.1, init_value=1e-2, act_layer=nn.GELU):
        super().__init__()
        self.d_model = d_model
        self.norm_1 = nn.GroupNorm(1, d_model)
        self.norm_2 = nn.GroupNorm(1, d_model)
        self.attn_1 = Spatial_Attn(d_model*T)
        self.ff = FeedForward(T, d_model)
        

    def forward(self, x):
        b, s, c, h, w = x.size()

        y = x
        y = y.reshape(b, s, c, h, w)
        y = y + self.attn_1(y)
        y = self.norm_1(y.view(-1, c, h, w)).view(b, s, c, h, w)
        y = y + self.ff(y)
        y = self.norm_2(y.view(-1, c, h, w)).view(b, s, c, h, w)
        return  y
    


class Spatial_Attn(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.d_model = d_model
        
        self.sa0_Conv = nn.Sequential(
            nn.Conv2d(self.d_model, self.d_model, kernel_size=1, bias=False),
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(), 
            nn.Conv2d(self.d_model, self.d_model, kernel_size=3, stride=1, padding=1,dilation=1, groups=self.d_model, bias=False),                       
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(),
                                    )
        self.sa1_Conv = nn.Sequential(
            nn.Conv2d(self.d_model, self.d_model, kernel_size=1, bias=False),
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(),  
            nn.Conv2d(self.d_model, self.d_model, kernel_size=3, stride=1, padding=3,dilation=3, groups=self.d_model, bias=False),                       
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(), 
                                    )
        self.sa2_Conv = nn.Sequential(
            nn.Conv2d(self.d_model, self.d_model, kernel_size=1, bias=False),
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(), 
            nn.Conv2d(self.d_model, self.d_model, kernel_size=3, stride=1, padding=5,dilation=5, groups=self.d_model, bias=False),                       
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(),  
                                    )
        self.sa3_Conv = nn.Sequential(
            nn.Conv2d(self.d_model, self.d_model, kernel_size=1, bias=False),
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(), 
            nn.Conv2d(self.d_model, self.d_model, kernel_size=5, stride=1, padding=2,dilation=1, groups=self.d_model, bias=False),                       
            nn.GroupNorm(1, self.d_model),
            nn.PReLU(),  
                                    )

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.reduction = 4
        self.fc = nn.Sequential(
            nn.Linear(d_model, d_model // self.reduction , bias=False), # reduction
            nn.ReLU(True),
            nn.Linear(d_model // self.reduction, d_model, bias=False), # expansion
            nn.Sigmoid()
        )
        self.sa_fusion = nn.Sequential(nn.Conv2d(d_model*5, d_model, kernel_size=1, bias=False), 
                                       nn.BatchNorm2d(d_model, eps=1e-5, momentum=0.01, affine=True),
                                       nn.PReLU())

    def forward(self, x):
        b, t, c, h, w = x.size()

        x = x.reshape(b, t*c, h, w)    # 16 640 16 16
    
        sa0 = self.sa0_Conv(x)
        sa1 = self.sa1_Conv(x)
        sa2 = self.sa2_Conv(x)
        sa3 = self.sa3_Conv(x)
        
        output = self.sa_fusion(torch.cat([x,sa0,sa1,sa2,sa3], dim=1))   # 16, 640, 16, 16
 
        u = output.clone()                                               # 16 640 16 16
        b_,c_,h_,w_ = output.size()
        se_atten = self.avg_pool(output).view(b_, c_)
        se_atten = self.fc(se_atten).view(b_, c_, 1, 1)   # 1 640 1 1s
        
        y = se_atten *  u 
        y = y.reshape(b, t, c, h, w)

        return y



class FeedForward(nn.Module):
    def __init__(self, T, d_model):
        super().__init__()

        self.ff1 = nn.Sequential(
            nn.Conv3d(d_model, 2*d_model, 3, 1, 1, bias=False),
            nn.GroupNorm(1, 2*d_model),
            nn.SiLU(inplace=True),
        )
        self.ff2 = nn.Sequential(
            nn.Conv3d(2*d_model, d_model, 3, 1, 1, bias=False),
            nn.GroupNorm(1, d_model),
            nn.SiLU(inplace=True),
        )
        mlp_ratio=4.0
        drop=0.0 
        drop_path=0.1
        init_value=1e-2
        self.norm2 = nn.BatchNorm2d(T*d_model)
        self.mlp = MixMlp(in_features=T*d_model, hidden_features=T*d_model, act_layer=nn.GELU, drop=0.0)
        mlp_hidden_dim = int(T*d_model * mlp_ratio)
        self.layer_scale_2 = nn.Parameter(init_value * torch.ones((T*d_model)), requires_grad=True)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()



    def forward(self, x):
        B, T, C, H, W = x.size()
        x = self.ff2(self.ff1(x.permute(0, 2, 1, 3, 4))).permute(0, 2, 1, 3, 4)
        
        x = x.reshape(B, T*C, H, W)       
        x = x + self.drop_path(self.layer_scale_2.unsqueeze(-1).unsqueeze(-1) * self.mlp(self.norm2(x))) 
        x = x.reshape(B, T,C, H, W)
        return x
    
class MixMlp(nn.Module):
    def __init__(self,
                 in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)  # 1x1
        self.dwconv = DWConv(hidden_features)                  # CFF: Convlutional feed-forward network
        self.act = act_layer()                                 # GELU
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1) # 1x1
        self.drop = nn.Dropout(drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x):
        x = self.dwconv(x)
        return x

