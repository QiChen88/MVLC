# Copyright (c) CAIRI AI Lab. All rights reserved

from .my_model import myModel

__all__ = ['my_model',]