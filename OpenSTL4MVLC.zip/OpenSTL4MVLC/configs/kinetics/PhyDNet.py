method = 'PhyDNet'
# model
patch_size = 4
# training
# lr = 1e-4
batch_size = 4  # 4 x bs4 = bs16
sched = 'cosine'
warmup_epoch = 0