# Copyright (c) CAIRI AI Lab. All rights reserved

from .my_method import My_Method


method_maps = {
    'my_method': My_Method,
    
}

__all__ = ['My_Method']